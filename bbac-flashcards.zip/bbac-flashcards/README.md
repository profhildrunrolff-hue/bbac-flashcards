# BBAC Flashcards

**Biography-Based Art Coaching · Module 1 Diagnostic Flashcards**  
Prof. Hildrun Rolff · earth-s institute · 2026

Bilingual interactive flashcard app (British English + Simplified Chinese).  
Designed for embedding in Funnelcockpit via iFrame.

---

## Files

```
bbac-flashcards/
├── index.html     ← the complete app (no build step needed)
├── cards.json     ← all 30 flashcards (edit content here)
└── README.md
```

---

## Setup: GitHub Pages in 3 steps

### 1 · Create a new repository

- Go to [github.com](https://github.com) → **New repository**
- Name: `bbac-flashcards` (or any name you prefer)
- Visibility: **Public** (required for free GitHub Pages)
- Click **Create repository**

### 2 · Upload the files

In your new repository:
- Click **Add file → Upload files**
- Upload `index.html`, `cards.json`, and `README.md`
- Click **Commit changes**

### 3 · Enable GitHub Pages

- Go to **Settings → Pages**
- Under *Source*, select **Deploy from a branch**
- Branch: `main` · Folder: `/ (root)`
- Click **Save**

After 1–2 minutes your app is live at:  
`https://YOUR-USERNAME.github.io/bbac-flashcards/`

---

## Embed in Funnelcockpit

In any Funnelcockpit page, insert an **HTML element** (or custom code block) with:

```html
<iframe
  src="https://YOUR-USERNAME.github.io/bbac-flashcards/"
  width="100%"
  height="620"
  frameborder="0"
  style="border-radius: 4px; border: 1px solid #DDD5C5;"
  loading="lazy"
  title="BBAC Flashcards">
</iframe>
```

Adjust `height` to taste. The app is fully responsive — it works on mobile inside the iFrame.

---

## Updating cards

All card content lives in `cards.json`. Each card has this structure:

```json
{
  "id": 1,
  "category": "Object Composition",
  "element": "earth",
  "q_en": "Question in English",
  "a_en": "Answer in English",
  "q_zh": "中文问题",
  "a_zh": "中文答案"
}
```

`element` must be one of: `earth` · `water` · `air` · `fire` · `general`

To add cards: append new objects to the JSON array and commit.  
GitHub Pages updates automatically within seconds.

---

## Features

- **Flip animation** — click or tap the card to reveal the answer
- **Language toggle** — EN · 中文 · Both (bilingual side-by-side on the answer)
- **Element filter** — Earth · Water · Air · Fire · General
- **Shuffle** — randomise the deck
- **Keyboard** — ← → to navigate · Space or Enter to flip
- **iFrame-ready** — no external dependencies except Google Fonts

---

*For questions: contact earth-s institute*
